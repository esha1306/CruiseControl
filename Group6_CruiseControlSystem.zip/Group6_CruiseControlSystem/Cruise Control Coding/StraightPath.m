
global v1
global v2  
global time_g
global Distance_g1
global time_g1
global Distance_g
global pts
global p
global p5
v1 = input('enter init values');
v2 = input ('Enter final values');
 avg_speed1 = v2-v1;
%  acc_avg1 = avg_speed1./t;

% title('Euclidian Distance based Object tracing for with collision of cars on Straight Path')
% xlabel('Variation of timimg points');
% ylabel('Variation of Distance from source car to obstacle car ');

handles.X = 1;
handles.Y= 1;
FigH1 = uifigure('Position',[100 100 350 275]);
handles.X1=20;
%main_speed = Distance_g1./time_g1;

FigH = uifigure('Position',[100 100 350 275]);

cg = uigauge(FigH,'Position',[20 140 120 120],'ScaleColors',{'yellow','red'},...
                 'ScaleColorLimits', [60 80; 80 100]);
cg.Value=0;
cg2 = uigauge(FigH1,'semicircular','Position',[200 200 80 80],'ScaleColors',{'yellow','red','blue'},...
                 'ScaleColorLimits', [3 10; 0 3;11 20;]);
cg2.Limits = [0 20];
cg2.MajorTicks=[0 5 10 15 20];
cg2.MinorTicks = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
% cg2.Value=10;
global cnt
btn = uibutton(FigH,'push','Text', 'Speed_cntrl',...
               'Position',[30 70 80 40],...
               'ButtonPushedFcn', @(btn,event) buttonCB(btn,event,cg,cnt));
% sld = uislider(FigH,...
%                'Position',[100 75 120 3],...
%                'ValueChangingFcn',@(sld,event) sliderMoving(event,cg));
btn2 =  uibutton(FigH1,'push','Text', 'Fuel_cntrl',...
               'Position',[20 25 80 35],...
               'ButtonPushedFcn', @(btn2,event) buttonCB2(btn2,event,cg2));
cnt= true;
cg2.Value = handles.X1;
guidata(FigH1, handles);
guidata(FigH, handles);
if(cnt==true && cg.Value<40)
    msgbox('CCS will be deactive');
    cnt=false;
    return
end
if(cnt==false && cg.Value>40)
    msgbox('CCS will be active');
    cnt=true;
    return
end

function buttonCB(ButtonH,event,cg,cnt)
cnt=false;
handles   = guidata(ButtonH);
handles.Y = handles.Y+5;
handles.X = handles.X+0;

hold on 
global v1
global v2 
  global time_g
 global Distance_g1
 global time_g1
 global Distance_g
 global pts
 global p
 global p5
 min_veh_speed = v2-v1;
 time_g =linspace(1,40,500);
Distance_g = min_veh_speed.*time_g;
plot(time_g,Distance_g)


 min_veh_speed1 = v2-v1;
time_g1 = linspace(3,40,500);
Distance_g1 = min_veh_speed1.*time_g1;

  plot(time_g1,Distance_g1,'g-')

 hold on
 p = plot(time_g(1),Distance_g(1),'o','MarkerFaceColor','red');
%plot(pts(4),pts(4,2),'red');
% axis([0,500,0,30000])

p5 = plot(time_g1(1),Distance_g1(1),'*','MarkerFaceColor','blue');
% plot(pts(40),pts(30,2),'g-');
tic
 
steps =1;
for k = 1:steps:500
    p.XData = time_g(k);
    p5.XData = time_g1(k);
    drawnow
    cg.Value = handles.X.*(round( p.XData));
    p.YData = Distance_g(k);    
    p5.YData = Distance_g1(k); 
    drawnow
    cg.Value = handles.X.*(round( p.XData));
     %%cg.Value = round(time_g(k));   
end
 
title('Euclidian Distance based Object tracing for with collision of cars on Straight Path')
xlabel('Variation of timimg points');
ylabel('Variation of Distance from source car to obstacle car ');
guidata(ButtonH, handles);
hold off;
disp(cnt)

end

function buttonCB2(ButtonH,event,cg2)
global x
global y
x = linspace(2,1,500);
y = linspace(2,1,500);
plot(x,y)
hold on

p= plot(x(1),y(1),'*','MarkerFaceColor','blue');
handles = guidata(ButtonH);
for k = 1:1:500
    p.XData = x(k);
    p.YData = y(k);
    handles.X1 = handles.X1-0.01;
    cg2.Value = round(handles.X1.*(( p.XData))/2);
    drawnow
    
    
end
(guidata(ButtonH,handles));

hold off
end