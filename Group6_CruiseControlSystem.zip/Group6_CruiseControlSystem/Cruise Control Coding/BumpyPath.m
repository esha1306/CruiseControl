global v1
global v2  
global time_g
global time_g1
global Distance_g
global pts
global p
global p5
v1 = input('enter init values');
v2 = input ('Enter final values');

  avg_speed1 = v2-v1;
%  acc_avg1 = avg_speed1./t;

% title('Euclidian Distance based Object tracing for with collision of cars on Straight Path')
% xlabel('Variation of timimg points');
% ylabel('Variation of Distance from source car to obstacle car ');

handles.X = 1;
handles.Y= 1;
FigH1 = uifigure('Position',[100 100 350 275]);
handles.X1=20;
% main_speed = Distance_g1./time_g1;

FigH = uifigure('Position',[100 100 350 275]);

cg = uigauge(FigH,'Position',[20 140 120 120],'ScaleColors',{'yellow','red'},...
                 'ScaleColorLimits', [60 80; 80 100]);
cg.Value=0;
cg2 = uigauge(FigH1,'semicircular','Position',[200 200 80 80],'ScaleColors',{'yellow','red','blue'},...
                 'ScaleColorLimits', [3 10; 0 3;11 20;]);
cg2.Limits = [0 20];
cg2.MajorTicks=[0 5 10 15 20];
cg2.MinorTicks = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
% cg2.Value=10;

btn = uibutton(FigH,'push','Text', 'Speed_cntrl',...
               'Position',[30 70 80 40],...
               'ButtonPushedFcn', @(btn,event) buttonCB(btn,event,cg));
% sld = uislider(FigH,...
%                'Position',[100 75 120 3],...
%                'ValueChangingFcn',@(sld,event) sliderMoving(event,cg));
btn2 =  uibutton(FigH1,'push','Text', 'Fuel_cntrl',...
               'Position',[20 25 80 35],...
               'ButtonPushedFcn', @(btn2,event) buttonCB2(btn2,event,cg2));

cg2.Value = handles.X1;
guidata(FigH, handles);
guidata(FigH1, handles);

if( cg.Value<40)
    warndlg('CCS will be deactive');
end


function buttonCB(ButtonH,event,cg)

global v1
global v2 
  global time_g
  global time_g1
 %global Distance_g1

 global Distance_g
% global pts
 global p
% if(cg.Value==40)
%       warndlg('CCS will be active'); 
% end

handles   = guidata(ButtonH);
handles.Y = handles.Y+1;
handles.X = handles.X+0;

 
% global p5
 min_veh_speed = v2-v1;


 time_g =linspace(1,80,500);
 time_g1= linspace(1,80,500);
Distance_g = min_veh_speed.*(cos(time_g).*cos(2*time_g) + 0.25*sin(time_g).*cos(time_g));
figure
 plot(time_g,Distance_g)
 hold on
 p = plot(time_g(1),Distance_g(1),'*','MarkerFaceColor','red');
 
 steps =5;

 for k= 1:steps:250
          p.XData = time_g(k);
          p.YData = Distance_g(k);   
         cg.Value = handles.X.*(round(p.XData));
     pause (0.5)
 end
 
pause(4);
 for i = 251:steps :500
     if (time_g(i)>=40 && time_g(i)< 60)
        p.XData = (time_g(i));
         p.YData = (Distance_g(i)); 
         drawnow
         cg.Value = handles.X.*(round(time_g(i)));    
     end
         if (time_g(i)>=60 && Distance_g(i)>0 && time_g(i)<80 )
             cg.Value= (round(time_g(i)));
         elseif(  Distance_g(i)<0 && time_g(i)<80)
             cg.Value= (round(time_g(i)))-handles.Y;
         else
             if( cg.Value==80)
                warndlg('CCS is active');
                pause(1);
            end
         end
 end

title(' CSS ACTIVE FOR CAR OBJECT TRACING ON BUMPY PATH')
xlabel('Variation of timimg points');
ylabel('Variation of Distance');
guidata(ButtonH, handles);

% disp(cnt)
hold off;
end
function buttonCB2(ButtonH,event,cg2)
global x
global y
x = linspace(2,1,500);
y = linspace(2,1,500);
plot(x,y)
hold on

p= plot(x(1),y(1),'*','MarkerFaceColor','blue');
set(p,'linewidth',4);
handles = guidata(ButtonH);
for k = 1:1:500
    p.XData = x(k);
    p.YData = y(k);
    handles.X1 = handles.X1-0.01;
    cg2.Value = round(handles.X1.*(( p.XData))/2);
    drawnow
    
    
end
(guidata(ButtonH,handles));

hold off
end
