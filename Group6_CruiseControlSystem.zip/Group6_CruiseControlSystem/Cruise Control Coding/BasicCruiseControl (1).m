FigH1 = uifigure('Position',[100 100 350 275]);
handles.X1=0;
handles.X=0;
cg = uigauge(FigH1,'Position',[20 140 120 120],'ScaleColors',{'yellow','red'},...
                 'ScaleColorLimits', [60 80; 80 100]);
cg.Value=0;
           
cg2 = uigauge(FigH1,'semicircular','Position',[200 200 80 80],'ScaleColors',{'yellow','red','blue'},...
                 'ScaleColorLimits', [3 10; 0 3;11 20;]);
cg2.Limits = [0 20];
cg2.MajorTicks=[0 5 10 15 20];
cg2.MinorTicks = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20];
btn = uibutton(FigH1,'push','Text', 'Speed_cntrl',...
               'Position',[30 70 80 40],...
               'ButtonPushedFcn', @(btn,event) buttonCB(btn,event,cg));

btn2 =  uibutton(FigH1,'push','Text', 'Throttle_chk',...
               'Position',[20 25 80 35],...
               'ButtonPushedFcn', @(btn2,event) buttonCB2(btn2,event,cg2));
 
function buttonCB(ButtonH,event,cg)

handles = guidata(ButtonH);
prompt = {'Enter speed:'};
title = 'SPEED RANGE';
x=inputdlg(prompt,title);
y = cell2mat(x);
k1 = str2double(y);
if (k1>=0 && k1<40)
    prompt1 = {'CCS DEACTIVE'};
    warndlg(prompt1);
    cg.Value = k1;
end
 if (k1>=40 && k1<=100)
     prompt2 = {'CCS ACTIVE'};
     warndlg(prompt2);
    cg.Value = k1;
end   
(guidata(ButtonH,handles));

hold off
end
 function buttonCB2(ButtonH,event,cg2)

handles = guidata(ButtonH);
prompt = {'Enter fuel:'};
title = 'FUEL RANGE';
x=inputdlg(prompt,title);
y = cell2mat(x);
k1 = str2double(y);
if (k1==0)
     prompt2 = {'NO FUEL '};
     warndlg(prompt2);
    cg2.Value = k1;
end 
if (k1>0 && k1<=3)
    prompt1 = {'FUEL RESERVE'};
    warndlg(prompt1);
    cg2.Value = k1;
end
 if (k1>3 && k1<=10)
     prompt2 = {'FUEL NEARLY HALF FULL'};
     warndlg(prompt2);
    cg2.Value = k1;
end   
if (k1>=11 && k1<20)
     prompt2 = {'FUEL NEARLY FULL'};
     warndlg(prompt2);
    cg2.Value = k1;
end 
if (k1==20)
     prompt2 = {'FUEL FULL'};
     warndlg(prompt2);
    cg2.Value = k1;
end 
(guidata(ButtonH,handles));

hold off
end